<?php

class database{
	public $host     = DB_HOST;
	public $user 	 = DB_USER;
	public $pass	 = DB_PASS;
	public $dbname	 = DB_NAME;
	
	public $links;
	public $error;
	
	public function __construct(){
		$this->connectDB();
	}
	private function connectDB(){
		$this->links = new mysqli($this->host, $this->user, $this->pass, $this->dbname);
		if(!$this->links){
			$this->error = "Connection Fail" . $this->links->connect_error;
			return false;
		}
	}
	//Select or read data
		
		public function select($query){
			$result = $this->links->query($query) or die ($this->links->error .__LINE__ );
			if($result->num_rows >0){
				return $result;
			}else{
				return false;
			}
		}
		
		//Create/Insert data
		
		public function insert($query){
			$insert_row = $this->links->query($query) or die ($this->links->error .__LINE__ );
			if($insert_row){
				header("Location: index.php?msg=".urlencode('Data Inserted Successfully'));
				exit();
			}else{
				die("Error : (".$this->links->errno.")" . $this->links->error);
			}
		}
		
		//Update data
		
		public function update($query){
			$update_row = $this->links->query($query) or die ($this->links->error .__LINE__ );
			if($update_row){
				header("Location: index.php?msg=".urlencode('Data Updated Successfully'));
				exit();
			}else{
				die("Error : (".$this->links->errno.")" . $this->links->error);
			}
		}
		//Delete data
		
		public function delete($query){
			$delete_row = $this->links->query($query) or die ($this->links->error .__LINE__ );
			if($delete_row){
				header("Location: index.php?msg=".urlencode('Data Deleted Successfully'));
				exit();
			}else{
				die("Error : (".$this->links->errno.")" . $this->links->error);
			}
		}

		
}