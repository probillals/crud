
<?php 
include "config.php";
include "database.php";

	$db     = new database();
	$query	= "SELECT * FROM tbl_user";
	$read 	= $db->select($query);
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>CRUD</title>
	<link rel="stylesheet" href="inc/style.css" />
	<style type="text/css">
		
	</style>
</head>
<body>
<center>

	<div class="wrap">
	
		<h1>CRUD using OOP PHP and MYSQLI</h1>
		<?php 
		
		if(isset($_GET['msg'])){
			echo "<span style='color:green'>".$_GET['msg']."</span>";
			
		}
		?>
		<table>
			<tr>
				<th width="10%">Serial No.</th>
				<th width="25%">Name</th>
				<th width="30%">Email</th>
				<th width="20%">Skill</th>
				<th width="15%">Action</th>
			</tr>
			<?php if($read){
				$i = 1;
				while ($row = $read->fetch_assoc()){
				?>
			
			<tr>
				<td><?php echo $i++;?></td>
				<td><?php echo $row['name'];?></td>
				<td><?php echo $row['email'];?></td>
				<td><?php echo $row['skill'];?></td>
				<td><a href="update.php?id=<?php echo urlencode($row['id']);?>">Edit</a></td>
			</tr>
			<?php } }else{ echo "data is not available";}?>
		</table>
	</br>
			<a class="btn" href="create.php">Create New Data</a>
		

		<h1><span>&copy; 2018 || All rights reserved to</span></br><a target="_blank" href="http://www.webit-academy.com">www.webit-academy.com</a></h1>
		
	</div>
</center>
</body>
</html>