
<?php 
include "config.php";
include "database.php";
	$id 		= $_GET['id'];
	$db    		= new database();
	$query		= "SELECT * FROM tbl_user WHERE id=$id";
	$getData 	= $db->select($query)->fetch_assoc();


	if(isset($_POST['submit'])){
		$name = mysqli_real_escape_string($db->links,$_POST['name']);
		$email = mysqli_real_escape_string($db->links,$_POST['email']);
		$skill = mysqli_real_escape_string($db->links,$_POST['skill']);
		if($name == '' || $email == '' || $skill == ''){
			$error = "Field must not be empty !!";
		}else{
			$query = "UPDATE tbl_user
			SET 
			name = '$name',
			email = '$email',
			skill = '$skill'
			WHERE id =$id";
			$update = $db->update($query);
		}
	}
?>

<?php 
//Delete
if(isset($_POST['delete'])){
	$query = "DELETE FROM tbl_user WHERE id=$id";
	$deleteDate = $db->delete($query);
}

?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>CRUD</title>
	<link rel="stylesheet" href="inc/style.css" />
	<style type="text/css">
		
	</style>
</head>
<body>
<center>

	<div class="wrap">
	
		<h1>CRUD using OOP PHP and MYSQLI</h1>
		<h1 style="color:#94C931">Update Data</h1>
		<?php 
		
		if(isset($error)){
			echo "<span style='color:red'>".$error."</span>";
			
		}
		?>	
	<form action="update.php?id=<?php echo $id;?>" method="post">
		<table>
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo $getData['name'];?>" /></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email" value="<?php echo $getData['email'];?>" /></td>
			</tr>	
			<tr>
				<td>Skill</td>
				<td><input type="text" name="skill" value="<?php echo $getData['skill'];?>" /></td>
			</tr>
			<tr>
				<td></td>
				<td>
					<button type="submit" name="submit">Update</button>
					<!--<button type="reset">Reset</button>-->
					<button type="submit" name="delete">Delete</button>
				</td>
			</tr>			
			
		</table>
	</form>
	</br>
		<a class="btn" href="index.php">Go Back</a>
		
		<h1><span>&copy; 2018 || All rights reserved to</span></br><a target="_blank" href="http://www.webit-academy.com">www.webit-academy.com</a></h1>
		
	</div>
</center>
</body>
</html>