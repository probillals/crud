
<?php 
include "config.php";
include "database.php";

	$db     = new database();
	if(isset($_POST['submit'])){
		$name = mysqli_real_escape_string($db->links,$_POST['name']);
		$email = mysqli_real_escape_string($db->links,$_POST['email']);
		$skill = mysqli_real_escape_string($db->links,$_POST['skill']);
		if($name == '' || $email == '' || $skill == ''){
			$error = "Field must not be empty !!";
		}else{
			$query = "INSERT INTO tbl_user(name,email,skill) Values('$name','$email','$skill')";
			$create = $db->insert($query);
		}
	}
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>CRUD</title>
	<link rel="stylesheet" href="inc/style.css" />
	<style type="text/css">

	</style>
</head>
<body>
<center>

	<div class="wrap">
	
		<h1>CRUD using OOP PHP and MYSQLI</h1>
		<h1 style="color:#94C931">Create New Data</h1>
		<?php 
		
		if(isset($error)){
			echo "<span style='color:red'>".$error."</span>";
			
		}
		?>	
	<form action="" method="post">
		<table>
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" placeholder="Please enter name" /></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email" placeholder="Please enter email" /></td>
			</tr>	
			<tr>
				<td>Skill</td>
				<td><input type="text" name="skill" placeholder="Please enter skill" /></td>
			</tr>
			<tr>
				<td></td>
				<td>
					<button type="submit" name="submit">Submit</button>
					<button type="reset">Reset</button>
				</td>
			</tr>			
			
		</table>
	</form>
	</br>
		<a class="btn" href="index.php">Go Back</a>
		
		<h1><span>&copy; 2018 || All rights reserved to</span></br><a target="_blank" href="http://www.webit-academy.com">www.webit-academy.com</a></h1>
		
	</div>
</center>
</body>
</html>